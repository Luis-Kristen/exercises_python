class Config:
    SECRET_KEY = 'SUPER SECRET'
